import 'package:flutter/material.dart';

// Paleta pastel: azules y rosados con un toque de lavanda para armonizar.
const colorList = <Color>[
  Color(0xFF7BA7DB), // azul pastel
  Color(0xFFF2A9C2), // rosado pastel
  Color(0xFFB9A7E6), // lavanda pastel
  Color(0xFF9ED3E6), // celeste pastel
  Color(0xFFF7C6D9), // rosa claro
  Color(0xFFA9C4F0), // azul cielo
];

class AppTheme {
  final int selectedColor;

  AppTheme({this.selectedColor = 0})
      : assert(selectedColor >= 0, 'El color debe ser mayor o igual a CERO'),
        assert(selectedColor < colorList.length,
            'El color debe ser menor a ${colorList.length - 1}');

  ThemeData getTheme() {
    final scheme = ColorScheme.fromSeed(
      seedColor: colorList[selectedColor],
      brightness: Brightness.light,
    ).copyWith(
      primary: const Color(0xFF7BA7DB),
      onPrimary: const Color(0xFF14243B),
      primaryContainer: const Color(0xFFDCEAFB),
      onPrimaryContainer: const Color(0xFF14243B),
      secondary: const Color(0xFFF2A9C2),
      onSecondary: const Color(0xFF3D1A28),
      secondaryContainer: const Color(0xFFFCE1EB),
      onSecondaryContainer: const Color(0xFF3D1A28),
      tertiary: const Color(0xFFB9A7E6),
      onTertiary: const Color(0xFF2A1F47),
      tertiaryContainer: const Color(0xFFEBE4FA),
      onTertiaryContainer: const Color(0xFF2A1F47),
      surface: const Color(0xFFFFF9FC),
      onSurface: const Color(0xFF2B2430),
      surfaceContainerHighest: const Color(0xFFF6E8F0),
      outline: const Color(0xFFB9A7C9),
      outlineVariant: const Color(0xFFE3D3EA),
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      appBarTheme: AppBarTheme(
        backgroundColor: scheme.secondaryContainer,
        foregroundColor: scheme.onSecondaryContainer,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        surfaceTintColor: Colors.transparent,
        shadowColor: scheme.primary.withAlpha(90),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: scheme.secondary,
        foregroundColor: scheme.onSecondary,
      ),
    );
  }
}
