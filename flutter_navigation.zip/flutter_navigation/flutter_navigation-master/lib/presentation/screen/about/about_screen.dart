import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textStyles = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Acerca de'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 56,
              backgroundColor: colors.primaryContainer,
              child: Icon(Icons.person, size: 64, color: colors.primary),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Brenda Isabel Gaviria Torres',
            textAlign: TextAlign.center,
            style: textStyles.headlineSmall,
          ),
          Text(
            'Estudiante de Ingeniería de Sistemas',
            textAlign: TextAlign.center,
            style: textStyles.bodyLarge?.copyWith(color: colors.primary),
          ),
          const SizedBox(height: 24),
          const Card(
            child: Column(
              children: [
                ListTile(
                  leading: Icon(Icons.school_outlined),
                  title: Text('Universidad'),
                  subtitle: Text(
                    'Fundación Universitaria Antonio de Arévalo (UNITECNAR)',
                  ),
                ),
                Divider(height: 0),
                ListTile(
                  leading: Icon(Icons.menu_book_outlined),
                  title: Text('Programa'),
                  subtitle: Text('Ingeniería de Sistemas'),
                ),
                Divider(height: 0),
                ListTile(
                  leading: Icon(Icons.location_on_outlined),
                  title: Text('Ciudad'),
                  subtitle: Text('Cartagena, Colombia'),
                ),
                Divider(height: 0),
                ListTile(
                  leading: Icon(Icons.phone_android),
                  title: Text('Asignatura'),
                  subtitle: Text('Desarrollo de aplicaciones móviles'),
                ),
                Divider(height: 0),

                ListTile(
                  leading: Icon(Icons.email_outlined),
                  title: Text('Correo'),
                  subtitle: Text('brendaisabel.gaviriatorres@unitecnar.edu.co'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
