import 'package:flutter/material.dart';

class CardsScreen extends StatelessWidget {
  const CardsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tarjetas'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _Section('Card (elevated)'),
          const Card(
            elevation: 4,
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Card elevada: es el tipo por defecto en Material 3.'),
            ),
          ),
          const _Section('Card.filled'),
          const Card.filled(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Card rellena, sin sombra pronunciada.'),
            ),
          ),
          const _Section('Card.outlined'),
          const Card.outlined(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Card con borde y sin relleno.'),
            ),
          ),
          const _Section('Card con ListTile'),
          const Card(
            child: ListTile(
              leading: Icon(Icons.album, size: 40),
              title: Text('Título de la tarjeta'),
              subtitle: Text('Subtítulo con información adicional.'),
              trailing: Icon(Icons.more_vert),
            ),
          ),
          const _Section('Card con acciones'),
          Card(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const ListTile(
                  leading: Icon(Icons.music_note),
                  title: Text('Canción favorita'),
                  subtitle: Text('Artista - Álbum'),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    TextButton(onPressed: () {}, child: const Text('Cancelar')),
                    const SizedBox(width: 8),
                    FilledButton(onPressed: () {}, child: const Text('Reproducir')),
                    const SizedBox(width: 8),
                  ],
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
          const _Section('Card con encabezado de color'),
          Card(
            clipBehavior: Clip.antiAlias,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 120,
                  width: double.infinity,
                  color: colors.primaryContainer,
                  child: Icon(Icons.landscape, size: 64, color: colors.primary),
                ),
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Cartagena de Indias, Colombia',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Text('Tarjeta con encabezado, título y descripción.'),
                ),
              ],
            ),
          ),
          const _Section('Card con InkWell (clickeable)'),
          Card(
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Card presionada')),
                );
              },
              child: const Padding(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(Icons.touch_app),
                    SizedBox(width: 12),
                    Expanded(child: Text('Toca esta tarjeta para ver el efecto.')),
                  ],
                ),
              ),
            ),
          ),
          const _Section('Card con forma y color personalizados'),
          Card(
            color: colors.secondaryContainer,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(28),
              side: BorderSide(color: colors.secondary, width: 2),
            ),
            child: const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: Text('Bordes redondeados y color propio')),
            ),
          ),
          const _Section('Card con margen y sin elevación'),
          const Card(
            elevation: 0,
            margin: EdgeInsets.symmetric(horizontal: 32, vertical: 8),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('Card con elevation: 0 y margen personalizado.'),
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  const _Section(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 8),
      child: Text(title, style: Theme.of(context).textTheme.titleMedium),
    );
  }
}
