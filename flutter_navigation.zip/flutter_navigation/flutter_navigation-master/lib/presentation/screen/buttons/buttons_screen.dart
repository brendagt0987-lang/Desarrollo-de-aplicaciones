import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ButtonsScreen extends StatefulWidget {
  const ButtonsScreen({super.key});

  @override
  State<ButtonsScreen> createState() => _ButtonsScreenState();
}

class _ButtonsScreenState extends State<ButtonsScreen> {
  String _segment = 'dia';
  final List<bool> _toggles = [true, false, false];
  String _dropdownValue = 'Uno';

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    void noop() {}

    return Scaffold(
      appBar: AppBar(
        title: const Text('Botones'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: noop,
        child: const Icon(Icons.arrow_back_ios_new_rounded),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _Section('ElevatedButton'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton(onPressed: noop, child: const Text('Elevated')),
              const ElevatedButton(onPressed: null, child: Text('Deshabilitado')),
              ElevatedButton.icon(
                onPressed: noop,
                icon: const Icon(Icons.access_alarm_rounded),
                label: const Text('Con icono'),
              ),
            ],
          ),
          const _Section('FilledButton'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FilledButton(onPressed: noop, child: const Text('Filled')),
              const FilledButton(onPressed: null, child: Text('Deshabilitado')),
              FilledButton.icon(
                onPressed: noop,
                icon: const Icon(Icons.add),
                label: const Text('Con icono'),
              ),
              FilledButton.tonal(onPressed: noop, child: const Text('Tonal')),
            ],
          ),
          const _Section('OutlinedButton'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton(onPressed: noop, child: const Text('Outlined')),
              const OutlinedButton(onPressed: null, child: Text('Deshabilitado')),
              OutlinedButton.icon(
                onPressed: noop,
                icon: const Icon(Icons.download),
                label: const Text('Con icono'),
              ),
            ],
          ),
          const _Section('TextButton'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              TextButton(onPressed: noop, child: const Text('Text')),
              const TextButton(onPressed: null, child: Text('Deshabilitado')),
              TextButton.icon(
                onPressed: noop,
                icon: const Icon(Icons.link),
                label: const Text('Con icono'),
              ),
            ],
          ),
          const _Section('IconButton'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              IconButton(onPressed: noop, icon: const Icon(Icons.favorite_border)),
              IconButton.filled(onPressed: noop, icon: const Icon(Icons.favorite)),
              IconButton.filledTonal(
                onPressed: noop,
                icon: const Icon(Icons.share),
              ),
              IconButton.outlined(
                onPressed: noop,
                icon: const Icon(Icons.bookmark_border),
              ),
            ],
          ),
          const _Section('FloatingActionButton'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              FloatingActionButton.small(
                heroTag: 'fab_small',
                onPressed: noop,
                child: const Icon(Icons.add),
              ),
              FloatingActionButton(
                heroTag: 'fab_regular',
                onPressed: noop,
                child: const Icon(Icons.add),
              ),
              FloatingActionButton.large(
                heroTag: 'fab_large',
                onPressed: noop,
                child: const Icon(Icons.add),
              ),
              FloatingActionButton.extended(
                heroTag: 'fab_extended',
                onPressed: noop,
                icon: const Icon(Icons.add),
                label: const Text('Extendido'),
              ),
            ],
          ),
          const _Section('SegmentedButton'),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'dia', label: Text('Día'), icon: Icon(Icons.wb_sunny)),
              ButtonSegment(value: 'semana', label: Text('Semana'), icon: Icon(Icons.view_week)),
              ButtonSegment(value: 'mes', label: Text('Mes'), icon: Icon(Icons.calendar_month)),
            ],
            selected: {_segment},
            onSelectionChanged: (value) =>
                setState(() => _segment = value.first),
          ),
          const _Section('ToggleButtons'),
          ToggleButtons(
            isSelected: _toggles,
            onPressed: (index) => setState(() {
              _toggles[index] = !_toggles[index];
            }),
            children: const [
              Icon(Icons.format_bold),
              Icon(Icons.format_italic),
              Icon(Icons.format_underline),
            ],
          ),
          const _Section('DropdownButton'),
          DropdownButton<String>(
            value: _dropdownValue,
            items: const ['Uno', 'Dos', 'Tres']
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (value) =>
                setState(() => _dropdownValue = value ?? _dropdownValue),
          ),
          const _Section('PopupMenuButton'),
          PopupMenuButton<String>(
            onSelected: (_) {},
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'a', child: Text('Opción A')),
              PopupMenuItem(value: 'b', child: Text('Opción B')),
            ],
          ),
          const _Section('CupertinoButton (iOS)'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              CupertinoButton(onPressed: noop, child: const Text('Cupertino')),
              CupertinoButton.filled(
                onPressed: noop,
                child: const Text('Cupertino filled'),
              ),
            ],
          ),
          const _Section('InkWell / GestureDetector (botón personalizado)'),
          Material(
            color: colors.primaryContainer,
            borderRadius: BorderRadius.circular(20),
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: noop,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                child: Text(
                  'Botón personalizado',
                  style: TextStyle(color: colors.onPrimaryContainer),
                ),
              ),
            ),
          ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  const _Section(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 8),
      child: Text(title, style: Theme.of(context).textTheme.titleMedium),
    );
  }
}
