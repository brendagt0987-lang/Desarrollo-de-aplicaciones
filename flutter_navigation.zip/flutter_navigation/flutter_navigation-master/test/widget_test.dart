import 'package:flutter_test/flutter_test.dart';

import 'package:flutter_navigation/main.dart';

void main() {
  testWidgets('El menú muestra Acerca de y Login', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());
    await tester.pumpAndSettle();

    expect(find.text('Botones'), findsOneWidget);
    expect(find.text('Tarjetas'), findsOneWidget);
    expect(find.text('Acerca de'), findsOneWidget);
    expect(find.text('Login'), findsOneWidget);
  });
}
