# app_form

Aplicación Flutter con formulario de login validado, rutas con `go_router`
y un dashboard con los datos del usuario autenticado.

## Usuarios de prueba

| Correo            | Contraseña |
|-------------------|------------|
| ana@correo.com    | ana12345   |
| carlos@correo.com | carlos123  |
| brenda@correo.com | brenda123  |

## Ejecutar

```bash
flutter create .      # solo la primera vez: genera android, ios, web, etc.
flutter pub get
flutter run
```
