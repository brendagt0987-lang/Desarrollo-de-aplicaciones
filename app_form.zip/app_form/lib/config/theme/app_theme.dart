import 'package:flutter/material.dart';

// Paleta pastel: azules y rosados con un toque de lavanda.
class AppTheme {
  ThemeData getTheme() {
    final scheme = ColorScheme.fromSeed(
      seedColor: const Color(0xFF7BA7DB),
      brightness: Brightness.light,
    ).copyWith(
      primary: const Color(0xFF7BA7DB),
      onPrimary: const Color(0xFF14243B),
      primaryContainer: const Color(0xFFDCEAFB),
      onPrimaryContainer: const Color(0xFF14243B),
      secondary: const Color(0xFFF2A9C2),
      onSecondary: const Color(0xFF3D1A28),
      secondaryContainer: const Color(0xFFFCE1EB),
      onSecondaryContainer: const Color(0xFF3D1A28),
      tertiary: const Color(0xFFB9A7E6),
      surface: const Color(0xFFFFF9FC),
      onSurface: const Color(0xFF2B2430),
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: scheme.surface,
      appBarTheme: AppBarTheme(
        backgroundColor: scheme.secondaryContainer,
        foregroundColor: scheme.onSecondaryContainer,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(50),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }
}
