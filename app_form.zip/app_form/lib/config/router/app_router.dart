import 'package:go_router/go_router.dart';
import 'package:app_form/presentation/screens/dashboard_screen.dart';
import 'package:app_form/presentation/screens/login_screen.dart';
import 'package:app_form/services/auth_service.dart';

final appRouter = GoRouter(
  initialLocation: '/login',
  // Cuando cambia el estado de sesión, se vuelve a evaluar el redirect.
  refreshListenable: AuthService.instance,
  redirect: (context, state) {
    final loggedIn = AuthService.instance.isLoggedIn;
    final goingToLogin = state.matchedLocation == '/login';

    if (!loggedIn && !goingToLogin) return '/login';
    if (loggedIn && goingToLogin) return '/dashboard';
    return null;
  },
  routes: [
    GoRoute(
      path: '/login',
      name: 'login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/dashboard',
      name: 'dashboard',
      builder: (context, state) => const DashboardScreen(),
    ),
  ],
);
