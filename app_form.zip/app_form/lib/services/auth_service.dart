import 'package:flutter/foundation.dart';
import 'package:app_form/data/users.dart';

/// Maneja el estado de autenticación. Es un ChangeNotifier para que
/// go_router reaccione (refreshListenable) cuando alguien inicia o cierra sesión.
class AuthService extends ChangeNotifier {
  AuthService._();
  static final AuthService instance = AuthService._();

  Map<String, String>? _currentUser;

  bool get isLoggedIn => _currentUser != null;
  Map<String, String>? get currentUser => _currentUser;

  /// Valida correo y contraseña contra el mapa [kUsers].
  bool login(String email, String password) {
    final key = email.trim().toLowerCase();
    final data = kUsers[key];

    if (data == null || data['password'] != password) {
      return false;
    }

    _currentUser = {...data, 'email': key};
    notifyListeners();
    return true;
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }
}
