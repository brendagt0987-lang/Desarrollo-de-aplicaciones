/// Mapa de usuarios (key = correo, value = datos del usuario).
/// Se usa para validar el login.
const Map<String, Map<String, String>> kUsers = {
 'yajaira.rodriguezelles@unitecnar.edu': {
    'password': 'yajaira12345',
    'name': 'Yajaira Rodríguez',
    'role': 'Analista de software',
    'city': 'Cartagena, Colombia',
    'phone': '+57 3145926100',
    'since': '2025',
    'avatar': 'assets/images/foto_yajaira.png',
  },
  'monkey.dluffy@unitecnar.edu': {
    'password': 'luffy1234',
    'name': 'Monkey D. Luffy',
    'role': 'Rey de los piratas',
    'city': 'Isla de Dawn',
    'phone': '+57 3202892499',
    'since': '2026',
    'avatar': 'assets/images/Luffy.png',
  },
  'brendaisabel.gaviriatorres@unitecnar.edu.co': {
    'password': 'brenda123',
    'name': 'Brenda Gaviria',
    'role': 'Desarrolladora',
    'city': 'Cartagena, Colombia',
    'phone': '+57 3202892497',
    'since': '2023',
    'avatar': 'assets/images/mi_foto.png',
  },
};
