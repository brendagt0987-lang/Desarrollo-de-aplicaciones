import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:app_form/services/auth_service.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  void _logout(BuildContext context) {
    AuthService.instance.logout();
    context.go('/login');
  }

  @override
  Widget build(BuildContext context) {
    final user = AuthService.instance.currentUser;
    // Durante el cierre de sesión el usuario ya es null.
    if (user == null) return const SizedBox.shrink();

    final colors = Theme.of(context).colorScheme;
    final textStyles = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            tooltip: 'Cerrar sesión',
            icon: const Icon(Icons.logout_rounded),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      body: ListView(
        children: [
          // Banner con el avatar superpuesto
          Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.bottomCenter,
            children: [
              Image.asset(
                'assets/images/banner.png',
                height: 180,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
              Positioned(
                bottom: -55,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: colors.primary.withAlpha(100),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: CircleAvatar(
                    radius: 55,
                    backgroundImage: AssetImage(user['avatar']!),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 66),
          Text(
            '¡Hola, ${user['name']}!',
            textAlign: TextAlign.center,
            style: textStyles.headlineSmall
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Center(
            child: Chip(
              avatar: Icon(Icons.verified_user_outlined,
                  size: 18, color: colors.onSecondaryContainer),
              label: Text(user['role']!),
              backgroundColor: colors.secondaryContainer,
              side: BorderSide.none,
            ),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Card(
              color: Colors.white,
              elevation: 3,
              shadowColor: colors.primary.withAlpha(90),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  _InfoTile(
                    icon: Icons.email_outlined,
                    title: 'Correo',
                    value: user['email']!,
                  ),
                  const Divider(height: 0),
                  _InfoTile(
                    icon: Icons.location_on_outlined,
                    title: 'Ciudad',
                    value: user['city']!,
                  ),
                  const Divider(height: 0),
                  _InfoTile(
                    icon: Icons.phone_outlined,
                    title: 'Teléfono',
                    value: user['phone']!,
                  ),
                  const Divider(height: 0),
                  _InfoTile(
                    icon: Icons.calendar_month_outlined,
                    title: 'Miembro desde',
                    value: user['since']!,
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: colors.secondary,
                foregroundColor: colors.onSecondary,
              ),
              onPressed: () => _logout(context),
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Cerrar sesión'),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const _InfoTile({
    required this.icon,
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return ListTile(
      leading: CircleAvatar(
        backgroundColor: colors.primaryContainer,
        child: Icon(icon, color: colors.onPrimaryContainer),
      ),
      title: Text(title),
      subtitle: Text(value),
    );
  }
}
