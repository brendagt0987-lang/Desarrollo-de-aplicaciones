import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:app_form/main.dart';

void main() {
  testWidgets('La app inicia en el login con dos campos', (tester) async {
    await tester.pumpWidget(const MyApp());
    await tester.pumpAndSettle();

    expect(find.byType(TextFormField), findsNWidgets(2));
    expect(find.text('Iniciar sesión'), findsOneWidget);
  });
}
